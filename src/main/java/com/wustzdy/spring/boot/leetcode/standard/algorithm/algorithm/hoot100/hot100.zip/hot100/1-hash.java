//1,两数之和
private static int[] twoSum1(int[] array, int target) {
    for (int i = 0; i < array.length; i++) {
        for (int j = i + 1; j < array.length; j++) {
            if (array[i] + array[j] == target) {
                return new int[]{i, j};
            }
        }
    }
    return new int[0];
}
//standard
public static int[] twoSum(int[] nums, int target) {
    //            6 3 8 2 1
    // map  key   6 3 8
    //      value 0 1 2

    HashMap<Integer, Integer> map = new HashMap<>();
    //一次遍历
    for (int i = 0; i < nums.length; ++i) {
        //存在时，我们用数组得值为 key，索引为 value
        if (map.containsKey(target - nums[i])) {
            return new int[]{map.get(target - nums[i]), i};
        }
        //存入值
        map.put(nums[i], i);
    }
    //返回
    return new int[0];
}
//4,128. 最长连续序列
// 给定一个未排序的整数数组 nums ，找出数字连续的最长序列（不要求序列元素在原数组中连续）的长度。
/*
输入：nums = [100,4,200,1,3,2]
输出：4
解释：最长数字连续序列是 [1, 2, 3, 4]。它的长度为 4。
*/
//[case1]如果nums[i]+1在set中存在，则表示nums[i]不是连续序列的最大值，那么我们继续向下遍历，不用做任何操作；
//[case2]如果nums[i]+1在set中不存在，则表示nums[i]是连续序列的最大值，那么我们执行倒序查找set中的元素，即：依次寻找nums[i]--的元素，并进行计数操作。
//https://baijiahao.baidu.com/s?id=1764759781447590028&wfr=spider&for=pc
public static int longestConsecutive1(int[] nums) {
    //100, 4, 200, 1, 3, 2
    int result = 0;
    Set<Integer> set = new HashSet();
    for (int num : nums) {
        set.add(num);
    }
    for (int num : nums) {
        if (!set.contains(num + 1)) {
            int max = 0;
            while (set.contains(num)) {
                max++;
                num--;
            }
            result = Math.max(result, max);
        }
    }
    return result;
}