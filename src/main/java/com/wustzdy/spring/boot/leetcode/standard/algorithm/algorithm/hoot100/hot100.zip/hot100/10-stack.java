//有效的括号
//给定一个只包括 '('，')'，'{'，'}'，'['，']' 的字符串 s ，判断字符串是否有效。
/*
输入：s = "()"
输出：true

输入：s = "()[]{}"
输出：true

输入：s = "(]"
输出：false
*/

/*
具体思路是遍历字符串中的每个字符，当遇到左括号时，将其对应的右括号入栈；当遇到右括号时，与栈顶元素比较，如果匹配则将栈顶元素出栈，否则返回 false。

最后检查栈是否为空，如果为空则表示字符串有效，否则表示字符串无效。

作者：GoAhead
链接：https://leetcode.cn/problems/valid-parentheses/solutions/2751506/pythonjava-you-xiao-de-gua-hao-by-goahea-x03w/
来源：力扣（LeetCode）
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
*/
public boolean isValid(String s) {
    Deque<Character> stack = new LinkedList<>();
    for (char i : s.toCharArray()) {
        if (i == '(') {
            stack.push(')');
        } else if (i == '[') {
            stack.push(']');
        } else if (i == '{') {
            stack.push('}');
        } else if (stack.isEmpty() || stack.pop() != i) {
            return false;
        }
    }
    return stack.isEmpty();
}

//每日温度
//给定一个整数数组 temperatures ，表示每天的温度，返回一个数组 answer ，其中 answer[i] 是指对于第 i 天，下一个更高温度出现在几天后。如果气温在这之后都不会升高，请在该位置用 0 来代替。
/**
输入: temperatures = [73,74,75,71,69,72,76,73]
输出: [1,1,4,2,1,1,0,0]

输入: temperatures = [30,40,50,60]
输出: [1,1,1,0]
 */
//暴力
public static int[] dailyTemperatures(int[] T) {
    //30,40,50,60
    int length = T.length;
    int[] result = new int[length];

    for (int i = 0; i < length; i++) {
        int current = T[i];
        if (current < 1000) {
            for (int j = i + 1; j < length; j++) {
                if (T[j] > current) {
                    result[i] = j - i;
                    break;
                }
            }
        }
    }
    return result;
}
public static int[] dailyTemperatures1(int[] T) {
    ////30,40,50,60
    int length = T.length;
    int[] result = new int[length];

    //从右向左遍历
    for (int i = length - 2; i >= 0; i--) {
        // j+= result[j]是利用已经有的结果进行跳跃
        for (int j = i + 1; j < length; j += result[j]) {
            if (T[j] > T[i]) {
                result[i] = j - i;
                break;
            } else if (result[j] == 0) { //遇到0表示后面不会有更大的值，那当然当前值就应该也为0
                result[i] = 0;
                break;
            }
        }
    }
    return result;
}