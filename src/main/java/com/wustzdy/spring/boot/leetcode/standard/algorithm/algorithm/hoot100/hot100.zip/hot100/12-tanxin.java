//121. 买卖股票的最佳时机
/*给定一个数组 prices ，它的第i 个元素prices[i] 表示一支给定股票第 i 天的价格。
        你只能选择 某一天 买入这只股票，并选择在 未来的某一个不同的日子 卖出该股票。
        设计一个算法来计算你所能获取的最大利润。
        返回你可以从这笔交易中获取的最大利润。如果你不能获取任何利润，返回 0 */
/*示例 1：
        输入：[7,1,5,3,6,4]
        输出：5
        解释：在第 2 天（股票价格 = 1）的时候买入，在第 5 天（股票价格 = 6）的时候卖出，最大利润 = 6-1 = 5 。
        注意利润不能是 7-1 = 6, 因为卖出价格需要大于买入价格；同时，你不能在买入前卖出股票。
        示例 2：

        输入：prices = [7,6,4,3,1]
        输出：0
        解释：在这种情况下, 没有交易完成, 所以最大利润为 0。*/

/***
 * 贪心的解释思路
//如果当前i下标对应的就是最小值，那么说明第i天卖出无法获取利润，直接不卖，利润是0
//如果当前i下标对应的不是最小值，那么说明可以在前i-1天以最低成本去买入股票，然后第i天卖出，利润=第i天价格-最低成本
//然后遍历，从局部利润，算出全局最大利润
 */
public static int maxProfit(int[] prices) {
    int maxprofit = 0;
    for (int i = 0; i < prices.length - 1; i++) {
        for (int j = i + 1; j < prices.length; j++) {
            int profit = prices[j] - prices[i];
            if (profit > maxprofit) {
                maxprofit = profit;
            }
        }
    }
    return maxprofit;
}//[7,1,5,3,6,4]
public static int maxProfit1(int prices[]) {
    int minprice = Integer.MAX_VALUE;
    int maxprofit = 0;
    for (int i = 0; i < prices.length; i++) {
        if (prices[i] < minprice) {////今天价格比之前的都低，不卖，只做记录
            minprice = prices[i];
        } else if (prices[i] - minprice > maxprofit) {//今天价格高，判断下利润是否比之前的记录利润都要大
            maxprofit = prices[i] - minprice;//今天利润最大，可以卖出
        }
    }
    return maxprofit;
}

//121. 买卖股票的最佳时机LL
/*
给你一个整数数组 prices ，其中 prices[i] 表示某支股票第 i 天的价格。
在每一天，你可以决定是否购买和/或出售股票。你在任何时候 最多 只能持有 一股 股票。你也可以先购买，然后在 同一天 出售。
返回 你能获得的 最大 利润 。
*/
/*
输入：prices = [7,1,5,3,6,4]
输出：7
解释：在第 2 天（股票价格 = 1）的时候买入，在第 3 天（股票价格 = 5）的时候卖出, 这笔交易所能获得利润 = 5 - 1 = 4 。
     随后，在第 4 天（股票价格 = 3）的时候买入，在第 5 天（股票价格 = 6）的时候卖出, 这笔交易所能获得利润 = 6 - 3 = 3 。
     总利润为 4 + 3 = 7 。
*/
//贪心
//https://www.bilibili.com/video/BV1ev4y1C7na/?spm_id_from=333.788&vd_source=5363405f0e14a0e8f06bcae41548f41e

/**
 * 股票价格：7   1  5  10  3  6  4
 * 每天利润     -6  4  5  -7  3  -2
 * 贪心 每天只收集正利润： 4+5+3
 */
//standard
public int maxProfit3(int[] prices) {
    int result = 0;
    for (int i = 1; i < prices.length; i++) {
        if (prices[i] - prices[i - 1] > 0) {
            result += prices[i] - prices[i - 1];
        }
    }
    return result;
}

//https://leetcode.cn/problems/best-time-to-buy-and-sell-stock-ii/
public static int maxProfit(int[] prices) {
    int len = prices.length;
    if (len < 2) {
        return 0;
    }

    // 0：持有现金
    // 1：持有股票
    // 状态转移：0 → 1 → 0 → 1 → 0 → 1 → 0
    int[][] dp = new int[len][2];

    dp[0][0] = 0;
    dp[0][1] = -prices[0];

    for (int i = 1; i < len; i++) {
        // 这两行调换顺序也是可以的
        dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
        dp[i][1] = Math.max(dp[i - 1][1], dp[i - 1][0] - prices[i]);
    }
    return dp[len - 1][0];
}


//跳跃游戏
//给你一个非负整数数组 nums ，你最初位于数组的 第一个下标 。数组中的每个元素代表你在该位置可以跳跃的最大长度
//判断你是否能够到达最后一个下标，如果可以，返回 true ；否则，返回 false 。
/**
 * 输入：nums = [2,3,1,1,4]
 * 输出：true
 * 解释：可以先跳 1 步，从下标 0 到达下标 1, 然后再从下标 1 跳 3 步到达最后一个下标。
 * <p>
 * 输入：nums = [3,2,1,0,4]
 * 输出：false
 * 解释：无论怎样，总会到达下标为 3 的位置。但该下标的最大跳跃长度是 0 ， 所以永远不可能到达最后一个下标。
 * https://www.bilibili.com/video/BV1VG4y1X7kB/?spm_id_from=333.788&vd_source=5363405f0e14a0e8f06bcae41548f41e
 * https://programmercarl.com/0055.%E8%B7%B3%E8%B7%83%E6%B8%B8%E6%88%8F.html#%E6%80%BB%E7%BB%93
 */
public boolean canJump(int[] nums) {
    if (nums.length == 1) {
        return true;
    }
    //覆盖范围, 初始覆盖范围应该是0，因为下面的迭代是从下标0开始的
    int coverRange = 0;
    //在覆盖范围内更新最大的覆盖范围
    for (int i = 0; i <= coverRange; i++) {
        coverRange = Math.max(coverRange, i + nums[i]);
        if (coverRange >= nums.length - 1) {
            return true;
        }
    }
    return false;
}

//跳跃游戏2
// 给定一个长度为 n 的 0 索引整数数组 nums。初始位置为 nums[0]。
// 每个元素 nums[i] 表示从索引 i 向前跳转的最大长度。换句话说，如果你在 nums[i] 处，你可以跳转到任意 nums[i + j] 处:
/**
输入: nums = [2,3,1,1,4]
输出: 2
解释: 跳到最后一个位置的最小跳跃数是 2。
     从下标为 0 跳到下标为 1 的位置，跳 1 步，然后跳 3 步到达数组的最后一个位置。
输入: nums = [2,3,0,1,4]
输出: 2
https://leetcode.cn/problems/jump-game-ii/?envType=study-plan-v2&envId=top-100-liked
 */
public int jump(int[] nums) {
    int end = 0;
    int maxPosition = 0;
    int steps = 0;
    for(int i = 0; i < nums.length - 1; i++){
        //找能跳的最远的
        maxPosition = Math.max(maxPosition, nums[i] + i);
        if( i == end){ //遇到边界，就更新边界，并且步数加一
            end = maxPosition;
            steps++;
        }
    }
    return steps;
}