//3，爬楼梯
public static int jumpFloor(int number) {
    int[] dp = new int[number + 1];//如果不初始化dp[0]，那就存数组的时候从1开始
    if (number == 1) {  //如果数组下标从1开始，那么这里1的情况就要单独加进去
        return 1;
    }
    dp[1] = 1;//到第一个台阶
    dp[2] = 2;//到第二个台阶
    for (int i = 3; i < number + 1; i++) {
        dp[i] = dp[i - 1] + dp[i - 2];
    }
    return dp[number];
}
private static int getClimbStairsLayer(int n) {
    if (n == 1) {
        return 1;
    } else if (n == 2) {
        return 2;
    } else {
        return getClimbStairsLayer(n - 1) + getClimbStairsLayer(n - 2);
    }
}

//4， 最小花费爬楼梯
//输入：cost = [1, 100, 1, 1, 1, 100, 1, 1, 100, 1]输出：6
//* 修改之后的题意就比较明确了，题目中说 “你可以选择从下标为 0 或下标为 1 的台阶开始爬楼梯” 
//也就是相当于 跳到 下标 0 或者 下标 1 是不花费体力的，
//从 下标 0 下标1 开始跳就要花费体力了。
/*dp[i]的定义：到达第i台阶所花费的最少体力为dp[i]。
对于dp数组的定义，大家一定要清晰！

确定递推公式
可以有两个途径得到dp[i]，一个是dp[i-1] 一个是dp[i-2]。
dp[i - 1] 跳到 dp[i] 需要花费 dp[i - 1] + cost[i - 1]。
dp[i - 2] 跳到 dp[i] 需要花费 dp[i - 2] + cost[i - 2]。
那么究竟是选从dp[i - 1]跳还是从dp[i - 2]跳呢？
一定是选最小的，所以dp[i] = min(dp[i - 1] + cost[i - 1], dp[i - 2] + cost[i - 2]);
*/
//https://blog.csdn.net/qq_68288689/article/details/131341822
//https://blog.csdn.net/qq_69369227/article/details/131528779?utm_medium=distribute.pc_relevant.none-task-blog-2~default~baidujs_baidulandingword~default-9-131528779-blog-127724999.235^v43^pc_blog_bottom_relevance_base3&spm=1001.2101.3001.4242.6&utm_relevant_index=12
public static int minCostClimbingStairs(int[] cost) {
    //dp 到达第i台阶所花费的最少体力为dp[i]。如果要向上跳，那么需要加上本身的花费const
    //2 5 20
    //0 0 0 0
    //0 0 2 5
    int len = cost.length;//
    int[] dp = new int[len + 1];

    // 从下标为 0 或下标为 1 的台阶开始，因此支付费用为0
    dp[0] = 0;
    dp[1] = 0;

    // 计算到达每一层台阶的最小费用
    for (int i = 2; i <= len; i++) {
        dp[i] = Math.min(dp[i - 1] + cost[i - 1], dp[i - 2] + cost[i - 2]);
    }
    return dp[len];
}

//杨辉三角
//给定一个非负整数 numRows，生成「杨辉三角」的前 numRows 行。
/*
输入: numRows = 5
输出: [[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]]
1
1 1
1 2 1
1 3 3 1
1 4 6 4 1
*/
public static List<List<Integer>> generate1(int numRows) {
    // 初始化动态规划数组
    Integer[][] dp = new Integer[numRows][];
    // 遍历每一行
    for (int i = 0; i < numRows; i++) {
        // 初始化当前行
        dp[i] = new Integer[i + 1];
        // 每一行的第一个和最后一个元素总是 1
        dp[i][0] = dp[i][i] = 1;
        // 计算中间元素
        for (int j = 1; j < i; j++) {
            // 中间元素等于上一行的相邻两个元素之和
            dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j];
        }
    }

    // 将动态规划数组转换为结果列表
    List<List<Integer>> result = new ArrayList<>();
    for (Integer[] row : dp) {
        result.add(Arrays.asList(row));
    }
    // 返回结果列表
    return result;
}

/*法一：
打家劫舍
动态规划
        首先考虑最简单的情况。如果只有一间房屋，则偷窃该房屋，可以偷窃到最高总金额。如果只有两间房屋，则由于两间房屋相邻，不能同时偷窃，只能偷窃其中的一间房屋，因此选择其中金额较高的房屋进行偷窃，可以偷窃到最高总金额。
        如果房屋数量大于两间，应该如何计算能够偷窃到的最高总金额呢？对于第 k (k>2) 间房屋，有两个选项：
        1，偷窃第 kkk 间房屋，那么就不能偷窃第 k−1间房屋，偷窃总金额为前 k−2间房屋的最高总金额与第 k间房屋的金额之和。
        2，不偷窃第 k间房屋，偷窃总金额为前 k−1间房屋的最高总金额。
        在两个选项中选择偷窃总金额较大的选项，该选项对应的偷窃总金额即为前 kkk 间房屋能偷窃到的最高总金额。

        用 dp[i]表示前 i间房屋能偷窃到的最高总金额，那么就有如下的状态转移方程：
        dp[i] = Math.max(dp[i - 2] + nums[i], dp[i - 1]);
        边界条件为：
        dp[0] = nums[0]; 只有一间房屋，则偷窃该房屋
        dp[1] = Math.max(nums[0], nums[1]);只有两间房屋，选择其中金额较高的房屋进行偷窃​

        最终的答案即为 dp[n−1]其中 nnn 是数组的长度。
        作者：力扣官方题解
        链接：https://leetcode.cn/problems/house-robber/solutions/263856/da-jia-jie-she-by-leetcode-solution/
 */
public class rob {
    public static void main(String[] args) {
        int[] nums = new int[]{2, 7, 9, 3, 1};
        int rob = rob(nums);
        System.out.println("rob:" + rob);//12
    }

    public static int rob(int[] nums) {
        if (nums == null || nums.length == 0) {
            return 0;
        }
        int length = nums.length;
        if (length == 1) {
            return nums[0];
        }
        int[] dp = new int[length];
        dp[0] = nums[0];
        dp[1] = Math.max(nums[0], nums[1]);
        for (int i = 2; i < length; i++) {
            dp[i] = Math.max(dp[i - 2] + nums[i], dp[i - 1]);
        }
        return dp[length - 1];
    }
}

//完全平方数
/*给你一个整数 n ，返回 和为 n 的完全平方数的最少数量 。
完全平方数 是一个整数，其值等于另一个整数的平方；换句话说，其值等于一个整数自乘的积。例如，1、4、9 和 16 都是完全平方数，而 3 和 11 不是。
输入：n = 12
输出：3 
解释：12 = 4 + 4 + 4

输入：n = 13
输出：2
解释：13 = 4 + 9
*/
public int numSquares(int n) {
int[] dp = new int[n + 1];
    Arrays.fill(dp, 10);
    dp[0] = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j * j <= i; j++) {
            dp[i] = Math.min(dp[i], dp[i - j * j] + 1);
        }
    }
    return dp[n];

}


//兑换零钱
/**
给你一个整数数组 coins ，表示不同面额的硬币；以及一个整数 amount ，表示总金额。
计算并返回可以凑成总金额所需的 最少的硬币个数 。如果没有任何一种硬币组合能组成总金额，返回 -1 。
你可以认为每种硬币的数量是无限的。
*/
/**
输入：coins = [1, 2, 5], amount = 11
输出：3 
解释：11 = 5 + 5 + 1
 */
//https://www.bilibili.com/video/BV1e64y1P7MQ/?spm_id_from=333.337.search-card.all.click&vd_source=5363405f0e14a0e8f06bcae41548f41e
public static int coinChange1(int[] coins, int amount) {
    // 创建一个数组来存储从0到目标金额的最少硬币数，初始值设置为目标金额加1（表示无法凑成）。
    int[] dp = new int[amount + 1];
    // 初始化数组的所有元素
    Arrays.fill(dp, amount + 1);
    // 金额为0时不需要任何硬币
    dp[0] = 0;
    // 遍历从1到目标金额的每个金额
    for (int i = 1; i <= amount; i++) {
        // 遍历每个可用的硬币面额。
        for (int coin : coins) {
            // 如果当前金额大于等于硬币面额，尝试更新当前金额的最少硬币数。
            if (i >= coin) {
                // 取当前金额最少硬币数和当前金额减去硬币面额的最少硬币数加1的最小值。
                dp[i] = Math.min(dp[i], dp[i - coin] + 1);
            }
        }
    }

    // 如果最终目标金额的最少硬币数仍为初始值（无法凑成目标金额），返回-1，否则返回最少硬币数。
    return dp[amount] == amount + 1 ? -1 : dp[amount];
}

public int coinChange(int[] coins, int amount) {
    int[] dp = new int[amount + 1];
    Arrays.fill(dp, amount + 1);
    dp[0] = 0;
    for (int coin : coins) {
        for (int j = coin; j <= amount; j++) {
            dp[j] = Math.min(dp[j], dp[j - coin] + 1);
        }
    }
    return dp[amount] == amount + 1 ? -1 : dp[amount];
}

// 给你一个字符串 s 和一个字符串列表 wordDict 作为字典。如果可以利用字典中出现的一个或多个单词拼接出 s 则返回 true。
//注意：不要求字典中出现的单词全部都使用，并且字典中的单词可以重复使用。
/**
输入: s = "leetcode", wordDict = ["leet", "code"]
输出: true
解释: 返回 true 因为 "leetcode" 可以由 "leet" 和 "code" 拼接成。

输入: s = "applepenapple", wordDict = ["apple", "pen"]
输出: true
解释: 返回 true 因为 "applepenapple" 可以由 "apple" "pen" "apple" 拼接成。
     注意，你可以重复使用字典中的单词。
 */
public static boolean wordBreak(String s, List<String> wordDict) {
    Set<String> set = new HashSet<>();
    for(String str:wordDict){
        set.add(str);
    }
    //前n个字符能否拆分 s = "leetcode", wordDict = ["leet", "code"]
    boolean[] dp = new boolean[s.length()+1];
    dp[0] = true;
    for(int i=0; i<s.length(); i++){
        for(int j=i+1; j<=s.length();j++){
            if(dp[i]&& set.contains(s.substring(i,j))){
                dp[j]=true;
            }
        }
    }
    return dp[s.length()];
}

//最长递增子序列
//给你一个整数数组 nums ，找到其中最长严格递增子序列的长度。
/*
输入：nums = [10,9,2,5,3,7,101,18]
输出：4
解释：最长递增子序列是 [2,3,7,101]，因此长度为 4 。
*/
public int lengthOfLIS(int[] nums) {
    if (nums.length == 0) {
        return 0;
    }
    int[] dp = new int[nums.length];
    dp[0] = 1;
    int maxans = 1;
    for (int i = 1; i < nums.length; i++) {
        dp[i] = 1;
        for (int j = 0; j < i; j++) {
            if (nums[i] > nums[j]) {
                dp[i] = Math.max(dp[i], dp[j] + 1);
            }
        }
        maxans = Math.max(maxans, dp[i]);
    }
    return maxans;
}

//乘积最大子数组
//给你一个整数数组 nums ，请你找出数组中乘积最大的非空连续子数组（该子数组中至少包含一个数字），并返回该子数组所对应的乘积。
/**
输入: nums = [2,3,-2,4]
输出: 6
解释: 子数组 [2,3] 有最大乘积 6。

输入: nums = [-2,0,-1]
输出: 0
解释: 结果不能为 2, 因为 [-2,-1] 不是子数组。
https://leetcode.cn/problems/maximum-product-subarray/solutions/7561/hua-jie-suan-fa-152-cheng-ji-zui-da-zi-xu-lie-by-g/?envType=study-plan-v2&envId=top-100-liked
*/
public int maxProduct(int[] nums) {
    int max = Integer.MIN_VALUE, imax = 1, imin = 1;
    for(int i=0; i<nums.length; i++){
        if(nums[i] < 0){ 
            int tmp = imax;
            imax = imin;
            imin = tmp;
        }
        imax = Math.max(imax*nums[i], nums[i]);
        imin = Math.min(imin*nums[i], nums[i]);
        
        max = Math.max(max, imax);
    }
    return max;

}

//分割等和子集
//给你一个 只包含正整数 的 非空 数组 nums 。请你判断是否可以将这个数组分割成两个子集，使得两个子集的元素和相等
/**
输入：nums = [1,5,11,5]
输出：true
解释：数组可以分割成 [1, 5, 5] 和 [11] 。

输入：nums = [1,2,3,5]
输出：false
解释：数组不能分割成两个元素和相等的子集。
 */


//8，不同路径
//一个机器人位于一个 m x n 网格的左上角 （起始点在下图中标记为 “Start” ）。
//机器人每次只能向下或者向右移动一步。机器人试图达到网格的右下角（在下图中标记为 “Finish” ）。
//问总共有多少条不同的路径？
//输入：m = 3, n = 7
//输出：28
/*示例 2：
        输入：m = 3, n = 2
        输出：3
        解释：
        从左上角开始，总共有 3 条路径可以到达右下角。
        1. 向右 -> 向下 -> 向下
        2. 向下 -> 向下 -> 向右
        3. 向下 -> 向右 -> 向下
*///然后只要让 dp[0][1] = 1 或者 dp[1][0] = 1 就可以了。格子都是有 右 和 上两个格的和
private static int uniquePathsFun(int m, int n) {
    int[][] dp = new int[m][n];
    for (int i = 0; i < m; i++) {
        dp[i][0] = 1;
    }
    for (int j = 0; j < n; j++) {
        dp[0][j] = 1;
    }
    for (int i = 1; i < m; i++) {
        for (int j = 1; j < n; j++) {
            dp[i][j]=dp[i-1][j]+dp[i][j-1];
        }
    }
    return dp[m-1][n-1];
}

//BM68 矩阵的最小路径和 
//https://www.bilibili.com/video/BV1yN411d7Pr/
//输入：[[1,3,5,9],[8,1,3,4],[5,0,6,1],[8,8,4,0]]
//输出：12
public static int minPathSum1(int[][] matrix) {
    // write code here
    int m = matrix.length; //matrix的行
    int n = matrix[0].length;//matrix的列
    int[][] dp = new int[m][n];//dp[i][j]代表在第i行第j列最小的路径和为多少
    dp[0][0] = matrix[0][0];//初始化dp[0][0]为matrix[0][0]
    for (int i = 1; i < m; i++) {
        dp[i][0] = dp[i - 1][0] + matrix[i][0];//初始化dp[i][0]
    }
    for (int i = 1; i < n; i++) {
        dp[0][i] = dp[0][i - 1] + matrix[0][i];//初始化dp[0][i]
    }
    for (int i = 1; i < m;i++) {
        for (int j = 1; j < n;j++) {
            //dp[i][j] 就应该等于在dp[i - 1][j]、dp[i][j - 1]选一个最小的在和matrix[i][j]加和
            dp[i][j] = Math.min(dp[i - 1][j], dp[i][j - 1]) + matrix[i][j];
        }
    }
    return dp[m - 1][n - 1];//最终的结果为dp[n-1][m-1]即二维表的最右下角
}
public static int minPathSum(int[][] matrix) {
    // write code here
    // 行数
    int m = matrix.length;
    // 列数
    int n = matrix[0].length;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (i == 0 && j == 0) {
                continue;
            } else if (i == 0) {
                matrix[i][j] += matrix[i][j - 1];
            } else if (j == 0) {
                matrix[i][j] += matrix[i - 1][j];
            } else {
                matrix[i][j] += Math.min(matrix[i - 1][j], matrix[i][j - 1]);
            }
        }
    }
    return matrix[m - 1][n - 1];
}


//5,//BM73 最长回文子串
//输入： "babad"
//    返回值： bab
//    说明： 最长的回文子串为"aba"与"bab"，长度都为3
public String longestPalindrome(String s) {
    if (s == null || s.length() < 1) {
        return "";
    }
    int start = 0, end = 0;
    for (int i = 0; i < s.length(); i++) {
        int len1 = expandAroundCenter(s, i, i);
        int len2 = expandAroundCenter(s, i, i + 1);
        int len = Math.max(len1, len2);
        if (len > end - start) {
            start = i - (len - 1) / 2;
            end = i + len / 2;
        }
    }
    return s.substring(start, end + 1);
}

public int expandAroundCenter(String s, int left, int right) {
    while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)) {
        --left;
        ++right;
    }
    return right - left - 1;
}

//6，判断给定字符串是否是回文串 stanard
private static Boolean IsPalindromicString(String s) {
    s = "abcba";
    int n = s.length();
    int left = 0;
    int right = n - 1;

    while (left < right) {
        if (s.charAt(left) == s.charAt(right)) {
            left++;
            right--;
        } else {
            return false;
        }
    }
    return true;
}
//是否为回文字串
private static boolean isPalindromic(String s) {
    int len = s.length();
    for (int i = 0; i < len / 2; i++) {
        if (s.charAt(i) != s.charAt(len - i - 1)) {
            return false;
        }
    }
    return true;
}
//求回文字串的长度
private static int isPalindromicString1(String s, int left, int right) {
    int length = s.length();
    while (left > 0 && right < length) {
        if (s.charAt(left) == s.charAt(right)) {
            left--;
            right++;
        } else {
            break;
        }
    }
    return right - left - 1;
}

////5,//BM73 最长回文子串
//输入： "babad"
//    返回值： bab
//    说明： 最长的回文子串为"aba"与"bab"，长度都为3
public static String longestPalindrome(String s) {
    //存储最长子串
    String str = "";
    //存储最长长度
    int longest = 0;
    for (int i = 0; i < s.length(); i++) {
        for (int j = i+1; j < s.length() + 1; j++) {
            String str1 = s.substring(i, j);
            if (isPalindromes(str1) && str1.length()>longest) {
                str = str1;
                longest= str.length();
            }
        }
    }
    return str;
}

public static boolean isPalindromes(String str) {
    if (str.length() == 1) {
        return true;
    }
    for (int i = 0; i < str.length() / 2; i++) {
        if (str.charAt(i) != str.charAt(str.length() - 1 - i)) {
            return false;
        }
    }
    return true;
}


// 7,1143.最长公共子序列-求长度
//给定两个字符串 text1 和 text2，返回这两个字符串的最长公共子序列的长度。
//输入：输入：text1 = "abcde", text2 = "ace"
//输出：3
//解释：最长公共子序列是 "ace"，它的长度为 3。
public static int longestCommonSubsequence(String text1, String text2) {
    // char[] char1 = text1.toCharArray();
    // char[] char2 = text2.toCharArray();
    // 可以在一開始的時候就先把text1, text2 轉成char[]，之後就不需要有這麼多爲了處理字串的調整
    // 就可以和卡哥的code更一致

    int[][] dp = new int[text1.length() + 1][text2.length() + 1]; // 先对dp数组做初始化操作
    for (int i = 1; i <= text1.length(); i++) {
        char char1 = text1.charAt(i - 1);
        for (int j = 1; j <= text2.length(); j++) {
            char char2 = text2.charAt(j - 1);
            if (char1 == char2) { // 开始列出状态转移方程
                dp[i][j] = dp[i - 1][j - 1] + 1;
            } else {
                dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }
    return dp[text1.length()][text2.length()];
}