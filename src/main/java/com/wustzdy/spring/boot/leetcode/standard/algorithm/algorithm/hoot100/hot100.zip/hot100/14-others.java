//只出现一次的数字
//给你一个 非空 整数数组 nums ，除了某个元素只出现一次以外，其余每个元素均出现两次。找出那个只出现了一次的元素。
/**
输入：nums = [2,2,1]
输出：1

输入：nums = [4,1,2,1,2]
输出：4
 */
public static int singleNumber1(int[] nums) {
    HashMap<Integer, Integer> map = new HashMap();
    for (int num : nums) {
        if (map.containsKey(num)) {
            map.put(num, map.get(num) + 1);
        } else {
            map.put(num, 1);
        }
    }
    System.out.println(map);//{1=2, 2=2, 4=1}

    for (Integer i : map.keySet()) {
        Integer count = map.get(i);
        if (count == 1) {
            return i;
        }
    }
    return 0;
}
//异或运算
public static int singleNumber2(int[] nums) {
    int single = 0;
    for (int num : nums) {
        single ^= num;
    }
    return single;
}
//多数元素
// 给定一个大小为 n 的数组 nums ，返回其中的多数元素。多数元素是指在数组中出现次数 大于 ⌊ n/2 ⌋ 的元素。
/*
输入：nums = [3,2,3]
输出：3

输入：nums = [2,2,1,1,1,2,2]
输出：2
*/
public int majorityElement(int[] nums) {
    Map<Integer, Integer> map = new HashMap<>();
    for (int num : nums) {
        if (map.containsKey(num)) {
            map.put(num, map.get(num) + 1);
        } else {
            map.put(num, 1);
        }
    }
    System.out.println(map);

    for (int num : map.keySet()) {
        int value = map.get(num);
        if (value > nums.length / 2) {
            return num;
        }
    }
    return -1;
}
public static int majorityElement3(int[] nums) {
    //2, 2, 1, 1, 1, 2, 2
    Arrays.sort(nums);//1,1,1,2,2,2,2
    for (int i : nums) {
        System.out.print(i+",");
    }
    return nums[nums.length / 2]; // 7/2=3 下标为3
}

//颜色分类
//给定一个包含红色、白色和蓝色、共 n 个元素的数组 nums ，原地对它们进行排序，使得相同颜色的元素相邻，并按照红色、白色、蓝色顺序排列。
//我们使用整数 0、 1 和 2 分别表示红色、白色和蓝色。
/**
输入：nums = [2,0,2,1,1,0]
输出：[0,0,1,1,2,2]
 */
/*我做本题的思想类似于刷漆

以[2 0 2 1 1 1 0]为例 大致可以这样理解：

[2 0 2 1 1 1 0] 
-> [2 2 2 2 2 2 2] 先全填上2
-> [1 1 1 1 1 2 2] 统计下0和1的个数之和(作为数字1的右侧边界)，然后填上1
-> [0 0 1 1 1 2 2] 统计下0的个数（作为数字0的右侧边界），然后填上0
*/
public void sortColors(int[] nums) {
    int one = 0,zero = 0;
    for(int i = 0; i<nums.length; i++){
        int tmp = nums[i];
        nums[i] = 2;
        if(tmp <= 1){
            nums[one] = 1;
            one++;
        }
        if(tmp == 0){
            nums[zero] = 0;
            zero++;
        }
    }
}
/**
 * 
 * 给定一个包含 n + 1 个整数的数组 nums ，其数字都在 [1, n] 范围内（包括 1 和 n），可知至少存在一个重复的整数。
假设 nums 只有 一个重复的整数 ，返回 这个重复的数 。
你设计的解决方案必须 不修改 数组 nums 且只用常量级 O(1) 的额外空间。
输入：nums = [1,3,4,2,2]
输出：2

输入：nums = [3,1,3,4,2]
输出：3

输入：nums = [3,3,3,3,3]
输出：3
 * 
 */

public int findDuplicate(int[] nums) {
    Set<Integer> map = new HashSet<Integer>();
    for(int num:nums){
        if(map.contains(num)){
            return num;
        }else{
            map.add(num);
        }
    }
    return 0;

}