//4,128. 最长连续序列
// 给定一个未排序的整数数组 nums ，找出数字连续的最长序列（不要求序列元素在原数组中连续）的长度。
/*
输入：nums = [100,4,200,1,3,2]
输出：4
解释：最长数字连续序列是 [1, 2, 3, 4]。它的长度为 4。
*/
//[case1]如果nums[i]+1在set中存在，则表示nums[i]不是连续序列的最大值，那么我们继续向下遍历，不用做任何操作；
//[case2]如果nums[i]+1在set中不存在，则表示nums[i]是连续序列的最大值，那么我们执行倒序查找set中的元素，即：依次寻找nums[i]--的元素，并进行计数操作。
//https://baijiahao.baidu.com/s?id=1764759781447590028&wfr=spider&for=pc
public static int longestConsecutive1(int[] nums) {
    //100, 4, 200, 1, 3, 2
    int result = 0;
    Set<Integer> set = new HashSet();
    for (int num : nums) {
        set.add(num);
    }
    for (int num : nums) {
        if (!set.contains(num + 1)) {
            int max = 0;
            while (set.contains(num)) {
                max++;
                num--;
            }
            result = Math.max(result, max);
        }
    }
    return result;
}


//定一个数组 nums，编写一个函数将所有 0 移动到数组的末尾，同时保持非零元素的相对顺序。
//请注意 ，必须在不复制数组的情况下原地对数组进行操作。
/*
输入: nums = [0,1,0,3,12]
输出: [1,3,12,0,0]
*/
//第一种
public void moveZeroes(int[] nums) {
    if(nums==null) {
        return;
    }
    //第一次遍历的时候，j指针记录非0的个数，只要是非0的统统都赋给nums[j]
    int j = 0;
    for(int i=0;i<nums.length;++i) {
        if(nums[i]!=0) {
            nums[j++] = nums[i];
        }
    }
    //非0元素统计完了，剩下的都是0了
    //所以第二次遍历把末尾的元素都赋为0即可
    for(int i=j;i<nums.length;++i) {
        nums[i] = 0;
    }
}
//第二种
public static int[] moveZeroes(int[] nums) {
    if (nums == null) {
        return null;
    }
    //两个指针i和j
    int j = 0;
    for (int i = 0; i < nums.length; i++) {
        //当前元素!=0，就把其交换到左边，等于0的交换到右边
        if (nums[i] != 0) {
            int tmp = nums[i];
            nums[i] = nums[j];
            nums[j++] = tmp;
        }
    }
    return nums;
}

//2,LeetCode第11题 盛最多水的容器
//第一种
public static int maxArea(int[] height) {
    int maxarea = 0;
    for (int i = 0; i < height.length; i++)
        for (int j = i + 1; j < height.length; j++)
            maxarea = Math.max(maxarea, Math.min(height[i], height[j]) * (j - i));
    return maxarea;
}
//第二种
//[1,8,6,2,5,4,8,3,7]
//s(0,8)=min(1,7)*(8-0)=8;
// res =max(res,s(0,8))=8
public int maxArea(int[] height) {
    int i = 0, j = height.length - 1, res = 0;
    while(i < j) {
        res = height[i] < height[j] ? 
            Math.max(res, (j - i) * height[i++]): 
            Math.max(res, (j - i) * height[j--]); 
    }
    return res;
}
//第三种
public int maxArea(int[] height) {
    public int maxArea(int[] height) {
        int maxArea = 0;
        int i = 0;
        int j = height.length-1;
        while (i < j) {
            if (height[i] < height[j]) {
                maxArea = Math.max(maxArea,(j - i) * height[i]);
                i++;
            } else {
                maxArea = Math.max(maxArea,(j - i) * height[j]);
                j--;
            }
        }
        return maxArea;
    }
}
//三数之和
//给你一个整数数组 nums ，判断是否存在三元组 [nums[i], nums[j], nums[k]] 满足 i != j、i != k 且 j != k ，同时还满足 nums[i] + nums[j] + nums[k] == 0 。请
//你返回所有和为 0 且不重复的三元组。
/*
输入：nums = [-1,0,1,2,-1,-4]
输出：[[-1,-1,2],[-1,0,1]]
https://leetcode.cn/problems/3sum/solutions/12307/hua-jie-suan-fa-15-san-shu-zhi-he-by-guanpengchn/?envType=study-plan-v2&envId=top-100-liked
思路
标签：数组遍历
首先对数组进行排序，排序后固定一个数 nums[i]，再使用左右指针指向 nums[i]后面的两端，数字分别为 nums[L] 和 nums[R]，计算三个数的和 sum判断是否满足为 0，满足则添加进结果集
如果 nums[i]大于 0，则三数之和必然无法等于 0，结束循环
如果 nums[i]== nums[i−1]，则说明该数字重复，会导致结果重复，所以应该跳过
当 sum== 0 时，nums[L] == nums[L+1] 则会导致结果重复，应该跳过，L++
当 sum== 0 时，nums[R] == nums[R−1] 则会导致结果重复，应该跳过，R−−
时间复杂度：O(n2)O(n^2)O(n 
2
 )，nnn 为数组长度

作者：画手大鹏
链接：https://leetcode.cn/problems/3sum/solutions/12307/hua-jie-suan-fa-15-san-shu-zhi-he-by-guanpengchn/
来源：力扣（LeetCode）
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
*/
//第一种
public static List<List<Integer>> threeSum(int[] nums) {
    List<List<Integer>> ans = new ArrayList();
    int len = nums.length;
    if (nums == null || len < 3)
        return ans;
    Arrays.sort(nums); // 排序
    //-4,-1,-1,0,1,2
    for (int i = 0; i < len; i++) {
        if (nums[i] > 0)
            break; // 如果当前数字大于0，则三数之和一定大于0，所以结束循环
        if (i > 0 && nums[i] == nums[i - 1])
            continue; // 去重
        int L = i + 1;
        int R = len - 1;
        while (L < R) {
            int sum = nums[i] + nums[L] + nums[R];
            if (sum == 0) {
                ans.add(Arrays.asList(nums[i], nums[L], nums[R]));
                while (L < R && nums[L] == nums[L + 1])
                    L++; // 去重
                while (L < R && nums[R] == nums[R - 1])
                    R--; // 去重
                L++;
                R--;
            } else if (sum < 0)
                L++;
            else if (sum > 0)
                R--;
        }
    }
    return ans;
}
//第二种
//https://leetcode.cn/problems/3sum/solutions/11525/3sumpai-xu-shuang-zhi-zhen-yi-dong-by-jyd/?envType=study-plan-v2&envId=top-100-liked
public static List<List<Integer>> threeSum1(int[] nums) {
    // -4,-1,-1,-1,0,1,2,
    Arrays.sort(nums);
    List<List<Integer>> res = new ArrayList<>();
    for (int k = 0; k < nums.length; k++) {
        if (nums[k] > 0)
            break;
        if (k > 0 && nums[k] == nums[k - 1])
            continue;
        int i = k + 1, j = nums.length - 1;

        while (i < j) {
            int sum = nums[k] + nums[i] + nums[j];
            if (sum < 0) {
                while (i < j && nums[i] == nums[++i])
                    ;
            } else if (sum > 0) {
                while (i < j && nums[j] == nums[--j])
                    ;
            } else {
                res.add(Arrays.asList(nums[k], nums[i], nums[j]));
                while (i < j && nums[i] == nums[++i])
                    ;
                while (i < j && nums[j] == nums[--j])
                    ;
            }
        }
    }
    return res;
}