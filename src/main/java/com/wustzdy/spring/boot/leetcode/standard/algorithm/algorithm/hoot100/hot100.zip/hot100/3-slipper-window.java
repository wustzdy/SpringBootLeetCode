//3. 无重复字符的最长子串-滑动窗口
 //https://leetcode.cn/problems/longest-substring-without-repeating-characters/solution/ren-zhe-suan-fa-7fen-zhong-bai-ban-dai-m-0u35/
 //给定一个字符串 s ，请你找出其中不含有重复字符的 最长子串 的长度。
/*示例 1:
        输入: s = "abcabcbb"
        输出: 3
        解释: 因为无重复字符的最长子串是 "abc"，所以其长度为 3。
        示例 2:
*/
/**
 * 什么是滑动窗口？
 * 其实就是一个队列,比如例题中的 abcabcbb，进入这个队列（窗口）为 abc 满足题目要求，当再进入 a，队列变成了 abca，这时候不满足要求。所以，我们要移动这个队列！
 * 如何移动？
 * 我们只要把队列的左边的元素移出就行了，直到满足题目要求！
 */
public static int lengthOfLongestSubstring4(String s) {
    int maxLength = 0;//abcabcbb
    int left = 0;
    int right = 0;
    Set<Character> windowSet = new HashSet<>();
    while (left < s.length() && right < s.length()) {
        if (windowSet.contains(s.charAt(right))) {
            windowSet.remove(s.charAt(left));
            left++;
        } else {
            windowSet.add(s.charAt(right));
            right++;
            int currentMaxLength = right - left;
            maxLength = Math.max(maxLength, currentMaxLength);
        }
    }
    return maxLength;
}