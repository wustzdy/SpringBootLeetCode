//子串
//7,和为K的子数组
// 1, 2,3
// k=2
//standard
public static int subarraySum3(int[] nums, int k) {
    // 前缀和数组
    int length = nums.length;
    int[] preSum = new int[length + 1];
    for (int i = 0; i < length; i++) {// 计算前缀和
        preSum[i + 1] = preSum[i] + nums[i];
    }
    //preSum=[0,1,3,6]

    int count = 0;// 统计和为 k 的子数组
    // 枚举所有子数组
    for (int i = 0; i < length; i++) {
        for (int j = i + 1; j <= length; j++) {
            if (preSum[j] - preSum[i] == k)
                count++;
        }
    }
    return count;
}
//第二种
public static int subarraySum(int[] nums, int k) {
    int count = 0;
    for (int start = 0; start < nums.length; ++start) {
        int sum = 0;
        for (int end = start; end >= 0; --end) {
            sum += nums[end];
            if (sum == k) {
                count++;
            }
        }
    }
    return count;
}