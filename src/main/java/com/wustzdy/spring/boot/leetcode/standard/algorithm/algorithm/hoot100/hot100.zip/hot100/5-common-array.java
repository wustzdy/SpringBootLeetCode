//8. 最大子数组和
/*如果 sum > 0，则说明 sum 对结果有增益效果，则 sum 保留并加上当前遍历数字
    如果 sum <= 0，则说明 sum 对结果无增益效果，需要舍弃，则 sum 直接更新为当前遍历数字
    每次比较 sum 和 max的大小，将最大值置为max，遍历结束返回结果
    https://leetcode.cn/problems/maximum-subarray/solutions/1/53-zui-da-zi-shu-zu-he-dong-tai-gui-hua-bvkq9/?envType=study-plan-v2&envId=top-100-liked
输入：nums = [-2,1,-3,4,-1,2,1,-5,4]
输出：6
解释：连续子数组 [4,-1,2,1] 的和最大，为 6 。

输入：nums = [5,4,-1,7,8]
输出：23
*/
public static int maxSubArray(int[] arr) {
    //-2, 1, -3, 4, -1, 2, 1, -5, 4
    int max = arr[0];
    int sum = arr[0];
    for (int i = 1; i < arr.length; i++) {
        if (sum > 0) {
            sum += arr[i];
        } else {
            sum = arr[i];
        }
        max = Math.max(sum, max);
    }
    return max;
}
//https://www.bilibili.com/video/BV1aY4y1Z7ya/?spm_id_from=333.788&vd_source=5363405f0e14a0e8f06bcae41548f41e
public static int maxSubArray2(int[] nums) {
    if (nums.length == 1) {
        return nums[0];
    }
    int sum = Integer.MIN_VALUE;
    int count = 0;
    for (int i = 0; i < nums.length; i++) {
        count += nums[i];
        if (count > sum) {
            sum = count;
        }
        if (count <= 0) {
            count = 0; // 相当于重置最大子序起始位置，因为遇到负数一定是拉低总和
        }
    }
    return sum;
}
//轮转数组：给定一个整数数组 nums，将数组中的元素向右轮转 k 个位置，其中 k 是非负数。
/*
输入: nums = [1,2,3,4,5,6,7], k = 3
输出: [5,6,7,1,2,3,4]
解释:
向右轮转 1 步: [7,1,2,3,4,5,6]
向右轮转 2 步: [6,7,1,2,3,4,5]
向右轮转 3 步: [5,6,7,1,2,3,4]
*/
//方法三：数组翻转
/*
该方法基于如下的事实：当我们将数组的元素向右移动 kkk 次后，尾部 k mod nk\bmod nkmodn 个元素会移动至数组头部，其余元素向后移动 k mod nk\bmod nkmodn 个位置。
该方法为数组的翻转：我们可以先将所有元素翻转，这样尾部的 k mod nk\bmod nkmodn 个元素就被移至数组头部，然后我们再翻转 [0,k mod n−1][0, k\bmod n-1][0,kmodn−1] 区间的元素和 [k mod n,n−1][k\bmod n, n-1][kmodn,n−1] 区间的元素即能得到最后的答案。
我们以 n=7n=7n=7，k=3k=3k=3 为例进行如下展示：
作者：力扣官方题解
链接：https://leetcode.cn/problems/rotate-array/solutions/551039/xuan-zhuan-shu-zu-by-leetcode-solution-nipk/
来源：力扣（LeetCode）
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
*/
/*
我们以 n=7，k=3 为例进行如下展示：
操作	结果
原始数组	1 2 3 4 5 6 7
翻转所有元素	7 6 5 4 3 2 1
翻转 [0,k mod n−1]区间的元素	5 6 7 4 3 2 1
翻转 [k mod n,n−1]区间的元素	5 6 7 1 2 3 4
*/
public void rotate(int[] nums, int k) {
    k %= nums.length;
    reverse(nums, 0, nums.length - 1);
    reverse(nums, 0, k - 1);
    reverse(nums, k, nums.length - 1);
}

public void reverse(int[] nums, int start, int end) {
    while (start < end) {
        int temp = nums[start];
        nums[start] = nums[end];
        nums[end] = temp;
        start += 1;
        end -= 1;
    }
}
/**
 * 给你一个整数数组 nums，返回 数组 answer ，其中 answer[i] 等于 nums 中除 nums[i] 之外其余各元素的乘积 。
 * 输入: nums = [1,2,3,4]
 * 输出: [24,12,8,6]
 *
 * 算法
 *对于给定索引 iii，我们将使用它左边所有数字的乘积乘以右边所有数字的乘积。
 * 初始化两个空数组 L 和 R。对于给定索引 i，L[i] 代表的是 i 左侧所有数字的乘积，R[i] 代表的是 i 右侧所有数字的乘积。
 * 我们需要用两个循环来填充 L 和 R 数组的值。对于数组 L，L[0] 应该是 1，因为第一个元素的左边没有元素。对于其他元素：L[i] = L[i-1] * nums[i-1]。
 * 同理，对于数组 R，R[length-1] 应为 1。length 指的是输入数组的大小。其他元素：R[i] = R[i+1] * nums[i+1]。
 * 当 R 和 L 数组填充完成，我们只需要在输入数组上迭代，且索引 i 处的值为：L[i] * R[i]。
 *
 * 作者：力扣官方题解
 * 链接：https://leetcode.cn/problems/product-of-array-except-self/solutions/272369/chu-zi-shen-yi-wai-shu-zu-de-cheng-ji-by-leetcode-/
 * 来源：力扣（LeetCode）
 * 著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
 */
public static int[] productExceptSelf(int[] nums) {
    int length = nums.length;//1 2 3 4

    // L 和 R 分别表示左右两侧的乘积列表
    int[] L = new int[length];//1 1 2 6
    int[] R = new int[length];//24 12 4 1

    int[] answer = new int[length];

    // L[i] 为索引 i 左侧所有元素的乘积
    // 对于索引为 '0' 的元素，因为左侧没有元素，所以 L[0] = 1
    L[0] = 1;
    for (int i = 1; i < length; i++) {
        L[i] = nums[i - 1] * L[i - 1];
    }

    // R[i] 为索引 i 右侧所有元素的乘积
    // 对于索引为 'length-1' 的元素，因为右侧没有元素，所以 R[length-1] = 1
    R[length - 1] = 1;
    for (int i = length - 2; i >= 0; i--) {
        R[i] = nums[i + 1] * R[i + 1];
    }

    // 对于索引 i，除 nums[i] 之外其余各元素的乘积就是左侧所有元素的乘积乘以右侧所有元素的乘积
    for (int i = 0; i < length; i++) {
        answer[i] = L[i] * R[i];
    }

    return answer;
}
//缺失的第一个正数
/**
 * 给你一个未排序的整数数组 nums ，请你找出其中没有出现的最小的正整数。请你实现时间复杂度为 O(n) 并且只使用常数级别额外空间的解决方案。
输入：nums = [1,2,0]
输出：3
解释：范围 [1,2] 中的数字都在数组中。

输入：nums = [3,4,-1,1]
输出：2
解释：1 在数组中，但 2 没有。
 * 方法一：哈希表（空间复杂度不符合要求）
按照刚才我们读例子的思路，其实我们只需从最小的正整数 111 开始，依次判断 222、 333 、444 直到数组的长度 NNN 是否在数组中；
如果当前考虑的数不在这个数组中，我们就找到了这个缺失的最小正整数；
https://leetcode.cn/problems/first-missing-positive/solutions/1/tong-pai-xu-python-dai-ma-by-liweiwei1419/
 */
public int firstMissingPositive(int[] nums) {
    int len = nums.length;

    Set<Integer> hashSet = new HashSet<>();
    for (int num : nums) {
        hashSet.add(num);
    }

    for (int i = 1; i <= len; i++) {
        if (!hashSet.contains(i)) {
            return i;
        }
    }

    return len + 1;
}