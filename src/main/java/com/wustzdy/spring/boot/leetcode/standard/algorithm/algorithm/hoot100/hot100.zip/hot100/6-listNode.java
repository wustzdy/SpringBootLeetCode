//单链表反转
/*[1,2,3,4,5] 链表反转后：[5,4,3,2,1]*/
//https://leetcode.cn/problems/reverse-linked-list/solutions/2361282/206-fan-zhuan-lian-biao-shuang-zhi-zhen-r1jel/
public class ListNodeReverse {
    public static void main(String[] args) {
        ListNode node5 = new ListNode(5, null);
        ListNode node4 = new ListNode(4, node5);
        ListNode node3 = new ListNode(3, node4);
        ListNode node2 = new ListNode(2, node3);
        ListNode oldLode = new ListNode(1, node2);
        System.out.println(oldLode);

        System.out.println("链表反转后：");
        ListNode newNode = ListNodeReverseFunction(oldLode);
        System.out.println(newNode);
    }
    private static ListNode ListNodeReverseFunction(ListNode oldNode) {
        ListNode newNode = null;
        ListNode p = oldNode;
        while (p != null) {
            newNode = new ListNode(p.val, newNode);
            p = p.next;
        }
        return newNode;
    }
    public static ListNode ReverseList(ListNode head) {
        if (head == null) {
            return null;
        }
        ListNode cur = head, pre = null;
        while (cur != null) {
            ListNode tmp = cur.next;//// 暂存后继节点 cur.next
            cur.next = pre;// 修改 next 引用指向
            pre = cur;// pre 暂存 cur
            cur = tmp;// cur 访问下一节点
        }
        return pre;
    }
    private static class ListNode {
        private int val;
        private ListNode next;

        public ListNode(int val, ListNode next) {
            this.val = val;
            this.next = next;
        }
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("[");
            ListNode p = this;
            while (p != null) {
                sb.append(p.val);
                if (p.next != null) {
                    sb.append(",");
                }
                p = p.next;
            }
            sb.append("]");
            return sb.toString();
        }
    }
}
//BM10 两个链表的第一个公共结点 
//输入：1 2 3 6 7
//       4 5 6 7
// 输出：6 7
//standard 第一种
public static ListNode getIntersectionNode(ListNode headA, ListNode headB) {
    //pHead1：1 2 3 6 7
    //pHead2：  4 5 6 7
    Set<ListNode> visited = new HashSet<ListNode>();
    ListNode temp = headA;
    while (temp != null) {
        visited.add(temp);
        temp = temp.next;
    }
    temp = headB;
    while (temp != null) {
        if (visited.contains(temp)) {
            return temp;
        }
        temp = temp.next;
    }
    return null;//6 7
}
//第二种
private static ListNode findFirstCommonNode(ListNode pHead1, ListNode pHead2) {
    ListNode node1 = pHead1;
    ListNode node2 = pHead2;
    while (node1 != node2) {///直到找到公共节点
        if (node1 == null) {
            node1 = pHead2;
        } else {
            node1 = node1.next;
        }

        if (node2 == null) {
            node2 = pHead1;
        } else {
            node2 = node2.next;
        }
    }
    return node1;
}
//3,BM13 判断一个链表是否为回文结构 
    // 给定一个链表，请判断该链表是否为回文结构。回文是指该字符串正序逆序完全一致。 
    //输入：{1,2,2,1}
    //返回值：true
    //说明：1->2->2->1
    /**
1.找到链表的中间节点
2.原地反转后半部分链表
3.比较前半部分和后半部分链表是否相同
*/
public boolean isPail (ListNode head) {
    // 要实现 O(n) 的时间复杂度和 O(1) 的空间复杂度，需要翻转后半部分
    if (head == null || head.next == null) {
        return true;
    }
    ListNode fast = head;
    ListNode slow = head;
    // 根据快慢指针，找到中间节点或者前半部分链表的尾节点（注意判断条件）
    while (fast.next != null && fast.next.next != null) {
        fast = fast.next.next;
        slow = slow.next;
    }
    // 反转后半部分链表
    slow = reverse(slow.next);
    while (slow != null) {
        if (head.val != slow.val) {
            return false;
        } else {
            head = head.next;
            slow = slow.next;
        }
    }
    return true;
}
public static ListNode reserve(ListNode head) {
    ListNode pre = null;
    ListNode cur = head;
    while (cur != null) {
        ListNode temp = cur.next;
        cur.next = pre;
        pre = cur;
        cur = temp;
    }
    return pre;
}
//方法2:
//我们使用快慢指针 ，fast一次走两步，slow一次走一步。当fast到达表尾的时候，slow正好到达一半的位置，
// 那么接下来可以从头开始逆序一半的元素，或者从slow开始逆序一半的元素，都可以。
 ListNode mid = findMid(oldLode);
ListNode l1 = oldLode, l2 = mid;
l2 = reverseList(l2.next);
boolean flag = isSame(l1, l2);
//1.找到链表的中间节点
private static ListNode findMid(ListNode head) {
    ListNode fast = head;
    ListNode slow = head;
    while (fast.next != null && fast.next.next != null) {
        fast = fast.next.next;
        slow = slow.next;
    }
    return slow;
}
//2.原地反转后半部分链表
private static ListNode reverseList(ListNode head) {
    ListNode cur = head, pre = null;
    while (cur != null) {
        ListNode tmp = cur.next;
        cur.next = pre;
        pre = cur;
        cur = tmp;
    }
    return pre;
}
// 3.比较前半部分和后半部分链表是否相同
private static boolean isSame(ListNode l1, ListNode l2) {
    ListNode p1 = l1, p2 = l2;
    while (p2 != null) {
        if (p1.val != p2.val) return false;
        p1 = p1.next;
        p2 = p2.next;
    }
    return true;
}

//给你一个链表的头节点 head ，判断链表中是否有环。
// 2， 判断链表中是否有环(环路检测)
    //输入：输入：{3,2,0,-4},1
    //返回值：true
    //说明：第一部分{3,2,0,-4}代表一个链表，第二部分的1表示，-4到位置1（注：头结点为位置0），即-4->2存在一个链接，组成传入的head为一个带环的链表，返回true   
/**
 * 我们使用快慢指针的方法来判断链表是否有环。我们让一个指针slow每次移动一步，另一个指针fast每次移动两步，如果链表有环，
那么fast指针最终会追上slow指针，从而形成一个循环。如果fast指针走到了链表的末尾，那么说明链表没有环。 
 */
ListNode node4 = new ListNode(-4, null);
    ListNode node3 = new ListNode(0, node4);
    ListNode node2 = new ListNode(2, node3);
    ListNode oldLode = new ListNode(3, node2);
    node4.next = node2;
    System.out.println(oldLode);//3 2 0 4 2

public boolean hasCycle(ListNode head) {
    if (head == null) return false;
    ListNode slow = head;
    ListNode fast = head;
    while (fast != null && fast.next != null) {
        slow = slow.next;
        fast = fast.next.next;
        if (slow == fast)
            return true;
    }
    return false;
}
// 返回链表开始入环的第一个节点
//给定一个链表的头节点  head ，返回链表开始入环的第一个节点。 如果链表无环，则返回 null。
// 1,和链表中环的入口节点-一个意思
//给定一个链表，如果它是有环链表，实现一个算法返回环路的开头节点。若环不存在，请返回 null。
//输入：1 2 3 4 5 3
//返回值：3
//说明：返回环形链表入口结点，我们后台程序会打印该环形链表入口结点对应的结点值，即3   
// 输入：head = [3,2,0,-4], pos = 1
// 输出：返回索引为 1 的链表节点
// 解释：链表中有一个环，其尾部连接到第二个节点。
public class Solution {
    public ListNode detectCycle(ListNode head) {
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
                ListNode index1 = fast;
                LisFtNode index2 = head;
                while (index1 != index2) {
                    index1 = index1.next;
                    index2 = index2.next;
                }
                return index1;
            }
        }
        return null;
    }
}
4,JZ25 合并两个排序的链表     
//输入两个递增的链表，单个链表的长度为n，合并这两个链表并使新链表中的节点仍然是递增排序的。
//如输入{1,3,5},{2,4,6}时，合并后的链表为{1,2,3,4,5,6}，所以对应的输出为{1,2,3,4,5,6} 
private static ListNode mergeListNode1(ListNode pHead1, ListNode pHead2) {
    //pHead1:1 3
    //pHead2:2 4
    ListNode dummy = new ListNode(0);
    ListNode cur = dummy;
    while (pHead1 != null && pHead2 != null) {
        if (pHead1.val < pHead2.val) {
            cur.next = pHead1;
            pHead1= pHead1.next;
        } else {
            cur.next = pHead2;
            pHead2 = pHead2.next;
        }
        cur = cur.next;
    }
    if (pHead1 == null) {
        cur.next = pHead2;
    } else {
        cur.next = pHead1;
    }
    return dummy.next;
}
//4,JZ25 合并两个排序的链表   
public ListNode Merge(ListNode list1, ListNode list2) {
    //一个已经为空了，直接返回另一个
    if (list1 == null) return list2;
    if (list2 == null) return list1;
    //加一个表头
    ListNode head = new ListNode(0);
    ListNode cur = head;
    //两个链表都要不为空
    while (list1 != null && list2 != null) {
        //取较小值的节点
        if (list1.val <= list2.val) {
            cur.next = list1;
            //只移动取值的指针
            list1 = list1.next;
        } else {
            cur.next = list2;
            //只移动取值的指针
            list2 = list2.next;
        }
        //指针后移
        cur = cur.next;
    }
    //哪个链表还有剩，直接连在后面
    if (list1 != null) 
        cur.next = list1;
    else 
       cur.next = list2;
    //返回值去掉表头
    return head.next;
}

5, 19.删除链表的倒数第N个节点
   //给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
   //输入：head = [1,2,3,4,5], n = 2 输出：[1,2,3,5] 示例 2：
   //https://programmercarl.com/0019.%E5%88%A0%E9%99%A4%E9%93%BE%E8%A1%A8%E7%9A%84%E5%80%92%E6%95%B0%E7%AC%ACN%E4%B8%AA%E8%8A%82%E7%82%B9.html#%E6%80%9D%E8%B7%AF

/**
 * 使用虚拟头结点，这样方便处理删除实际头结点的逻辑
 * 1,定义fast指针和slow指针，初始值为虚拟头结点
 * 2,ast首先走n + 1步 ，为什么是n+1呢，因为只有这样同时移动的时候slow才能指向删除节点的上一个节点（方便做删除操作），
 */
public ListNode removeNthFromEnd(ListNode head, int n){
    ListNode dummyNode = new ListNode(0);
    dummyNode.next = head;

    ListNode fastIndex = dummyNode;
    ListNode slowIndex = dummyNode;

    //只要快慢指针相差 n 个结点即可
    for (int i = 0; i < n  ; i++){
        fastIndex = fastIndex.next;
    }

    while (fastIndex.next != null){
        fastIndex = fastIndex.next;
        slowIndex = slowIndex.next;
    }

    //此时 slowIndex 的位置就是待删除元素的前一个位置。
    //具体情况可自己画一个链表长度为 3 的图来模拟代码来理解
    slowIndex.next = slowIndex.next.next;
    return dummyNode.next;
}

//两两交换链表中的节点
//给你一个链表，两两交换其中相邻的节点，并返回交换后链表的头节点。你必须在不修改节点内部的值的情况下完成本题（即，只能进行节点交换）。
//输入：head = [1,2,3,4]
//        输出：[2,1,4,3]

public static ListNode swapPairs(ListNode head) {
    ListNode dummy = new ListNode(0);
    dummy.next = head;
    for (ListNode p = dummy; p.next != null && p.next.next != null; ) {
        ListNode a = p.next;    //虚拟头节点
        ListNode b = a.next;
        p.next = b;
        a.next = b.next;
        b.next = a;
        p = a;
    }
    return dummy.next;
}

//13，链表排序，
//找到中点，再断开，归实现链表归并排序，
private static ListNode sortNode(ListNode head) {
    if (head == null || head.next == null) {
        return head;
    }

    ListNode fast = head.next, slow = head;
    while (fast != null && fast.next != null) {
        slow = slow.next;
        fast = fast.next.next;
    }

    // 将链表从fast与mid之间断开，切分成head和tmp两部分
    ListNode tmp = slow.next;
    slow.next = null;

    ListNode left = sortNode(head);
    ListNode right = sortNode(tmp);

    ListNode dummyHead = new ListNode(-1);
    ListNode curr = dummyHead;

    while (left != null && right != null) {
        if (left.val < right.val) {
            curr.next = left;
            left = left.next;
        } else {
            curr.next = right;
            right = right.next;
        }

        curr = curr.next;
    }

    if (left == null) {
        curr.next = right;
    } else {
        curr.next = left;
    }
    return dummyHead.next;
}
//请你设计并实现一个满足  LRU (最近最少使用) 缓存 约束的数据结构。
/*
实现 LRUCache 类：

    LRUCache(int capacity) 以 正整数 作为容量 capacity 初始化 LRU 缓存
    int get(int key) 如果关键字 key 存在于缓存中，则返回关键字的值，否则返回 -1 。
    void put(int key, int value) 如果关键字 key 已经存在，则变更其数据值 value ；如果不存在，则向缓存中插入该组 key-value 。如果插入操作导致关键字数量超过 capacity ，则应该 逐出 最久未使用的关键字。

函数 get 和 put 必须以 O(1) 的平均时间复杂度运行
*/
class LRUCache extends LinkedHashMap<Integer, Integer> {
    private int capacity;

    public LRUCache(int capacity) {
        super(capacity, 0.75F, true);
        this.capacity = capacity;
    }

    public int get(int key) {
        return super.getOrDefault(key, -1);
    }

    public void put(int key, int value) {
        super.put(key, value);
    }

    @Override
    protected boolean removeEldestEntry(Map.Entry<Integer, Integer> eldest) {
        return size() > capacity;
    }
}