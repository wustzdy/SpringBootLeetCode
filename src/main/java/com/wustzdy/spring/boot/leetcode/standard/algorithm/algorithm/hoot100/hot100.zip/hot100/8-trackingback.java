//全排列
/**
给定一个不含重复数字的数组 nums ，返回其 所有可能的全排列 。你可以 按任意顺序 返回答案。
输入：nums = [1,2,3]
输出：[[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]

输入：nums = [0,1]
输出：[[0,1],[1,0]]
https://www.bilibili.com/video/BV19v4y1S79W/?spm_id_from=333.788&vd_source=5363405f0e14a0e8f06bcae41548f41e
 */
public List<List<Integer>> result = new ArrayList<>();// 存放符合条件结果的集合
public List<Integer> path = new ArrayList<>();// 用来存放符合条件结果
public boolean[] used;

public List<List<Integer>> permute(int[] nums) {
    if (nums.length == 0) {
        return result;
    }
    used = new boolean[nums.length];
    backtracking(nums);
    return result;
}

private void backtracking(int[] nums) {
    if (path.size() == nums.length) {
        result.add(new ArrayList<>(path));
        return;
    }
    for (int i = 0; i < nums.length; i++) {
        if (used[i]) {
            continue;
        }
        used[i] = true;
        path.add(nums[i]);
        backtracking(nums);
        path.remove(path.size() - 1);
        used[i] = false;
    }
}

/** 组合
 * 定两个整数 n 和 k，返回 1 ... n 中所有可能的 k 个数的组合。
 * <p>
 * 示例: 输入: n = 4, k = 2 输出: [ [2,4], [3,4], [2,3], [1,2], [1,3], [1,4], ]
 * #
 * //https://programmercarl.com/0077.%E7%BB%84%E5%90%88.html#%E7%AE%97%E6%B3%95%E5%85%AC%E5%BC%80%E8%AF%BE
 * <p>
 * //直接的解法当然是使用for循环，例如示例中k为2，很容易想到 用两个for循环，这样就可以输出 和示例中一样的结果。
 */
public class combine {
    public static void main(String[] args) {
        test2();//1,2],[1,3],[1,4],[2,3],[2,4],[3,4],[
        int n = 4;
        int k = 2;
        List<List<Integer>> combine = combine(n, k);
        System.out.println("combine:" + combine);//[[1, 2], [1, 3], [1, 4], [2, 3], [2, 4], [3, 4]]
    }

    public static void test2() {
        //直接的解法当然是使用for循环，例如示例中k为2，
        // 很容易想到 用两个for循环，这样就可以输出 和示例中一样的结果。
        int n = 4;
        for (int i = 1; i <= n; i++) {
            for (int j = i + 1; j <= n; j++) {
                System.out.print(i + "," + j + "],[");
            }
        }
    }

    public static void test3() {
        //输入：n = 100, k = 3 那么就三层for循环，代码如下：
        int n = 100;
        for (int i = 1; i <= n; i++) {
            for (int j = i + 1; j <= n; j++) {
                for (int u = j + 1; u <= n; n++) {
                    System.out.print(i + "," + j + "," + "],[");
                }
            }
        }
    }

    //standard
    public static List<List<Integer>> combine(int n, int k) {
        List<List<Integer>> result = new ArrayList<>();
        List<Integer> path = new ArrayList<>();
        backtracking(result, path, n, k, 1);
        return result;
    }

    public static void backtracking(List<List<Integer>> result,
                                    List<Integer> path,
                                    int n, int k, int startIndex) {
        if (path.size() == k) {
            result.add(new ArrayList<>(path));
            return;
        }
        for (int i = startIndex; i <= n; i++) {
            path.add(i);
            backtracking(result, path, n, k, i + 1);
            path.remove(path.size() - 1);
        }
    }
}

/**
子集
给你一个整数数组 nums ，数组中的元素 互不相同 。返回该数组所有可能的子集
解集 不能 包含重复的子集。你可以按 任意顺序 返回解集。

输入：nums = [1,2,3]
输出：[[],[1],[2],[1,2],[3],[1,3],[2,3],[1,2,3]]

输入：nums = [0]
输出：[[],[0]]
 * 
 https://www.bilibili.com/video/BV1U84y1q7Ci/?spm_id_from=333.788&vd_source=5363405f0e14a0e8f06bcae41548f41e
 */
class Solution {
    public List<List<Integer>> result = new ArrayList<>();// 存放符合条件结果的集合
    public static List<Integer> path = new ArrayList<>();// 用来存放符合条件结果

    public List<List<Integer>> subsets(int[] nums) {
        backtracking(nums, 0);
        return result;
    }

    private void backtracking(int[] nums, int startIndex) {
        result.add(new ArrayList<>(path));// 「遍历这个树的时候，把所有节点都记录下来，就是要求的子集集合」。
        if (startIndex >= nums.length) { // 终止条件可不加
            return;
        }
        for (int i = startIndex; i < nums.length; i++) {
            path.add(nums[i]);
            backtracking(nums, i + 1);
            path.remove(path.size() - 1);
        }
    }
}
//电话号码的字母组合
/**
给定一个仅包含数字 2-9 的字符串，返回所有它能表示的字母组合。答案可以按 任意顺序 返回。
给出数字到字母的映射如下（与电话按键相同）。注意 1 不对应任何字母。
输入：digits = "23"
输出：["ad","ae","af","bd","be","bf","cd","ce","cf"]

输入：digits = "2"
输出：["a","b","c"]
 * https://programmercarl.com/0017.%E7%94%B5%E8%AF%9D%E5%8F%B7%E7%A0%81%E7%9A%84%E5%AD%97%E6%AF%8D%E7%BB%84%E5%90%88.html#%E6%80%9D%E8%B7%AF
 */
class Solution {
    public List<String> letterCombinations(String digits) {
        List<String> combinations = new ArrayList<String>();
        if (digits.length() == 0) {
            return combinations;
        }
        Map<Character, String> phoneMap = new HashMap<Character, String>() {{
            put('2', "abc");
            put('3', "def");
            put('4', "ghi");
            put('5', "jkl");
            put('6', "mno");
            put('7', "pqrs");
            put('8', "tuv");
            put('9', "wxyz");
        }};
        backtrack(combinations, phoneMap, digits, 0, new StringBuffer());
        return combinations;
    }

    public void backtrack(List<String> combinations, Map<Character, String> phoneMap, String digits, int index, StringBuffer combination) {
        if (index == digits.length()) {
            combinations.add(combination.toString());
        } else {
            char digit = digits.charAt(index);
            String letters = phoneMap.get(digit);
            int lettersCount = letters.length();
            for (int i = 0; i < lettersCount; i++) {
                combination.append(letters.charAt(i));
                backtrack(combinations, phoneMap, digits, index + 1, combination);
                combination.deleteCharAt(index);
            }
        }
    }
}

//组合总和
/**
 给你一个 无重复元素 的整数数组 candidates 和一个目标整数 target ，找出 candidates 中可以使数字和为目标数 target 的 所有 不同组合 ，并以列表形式返回。你可以按 任意顺序 返回这些组合。
candidates 中的 同一个 数字可以 无限制重复被选取 。如果至少一个数字的被选数量不同，则两种组合是不同的。
输入：candidates = [2,3,6,7], target = 7
输出：[[2,2,3],[7]]
解释：
2 和 3 可以形成一组候选，2 + 2 + 3 = 7 。注意 2 可以使用多次。
7 也是一个候选， 7 = 7 。
仅有这两种组合。

输入: candidates = [2,3,5], target = 8
输出: [[2,2,2,2],[2,3,3],[3,5]]
 */
public static List<List<Integer>> combinationSum(int[] candidates, int target) {
    List<List<Integer>> res = new ArrayList<>();
    Arrays.sort(candidates); // 先进行排序
    backtracking(res, new ArrayList<>(), candidates, target, 0, 0);
    return res;
}

public static void backtracking(List<List<Integer>> res, List<Integer> path, int[] candidates, int target, int sum, int idx) {
    // 找到了数字和为 target 的组合
    if (sum == target) {
        res.add(new ArrayList<>(path));
        return;
    }

    for (int i = idx; i < candidates.length; i++) {
        // 如果 sum + candidates[i] > target 就终止遍历
        if (sum + candidates[i] > target) break;
        path.add(candidates[i]);
        backtracking(res, path, candidates, target, sum + candidates[i], i);
        path.remove(path.size() - 1); // 回溯，移除路径 path 最后一个元素
    }
}

//单词搜索
/**
给定一个 m x n 二维字符网格 board 和一个字符串单词 word 。如果 word 存在于网格中，返回 true ；否则，返回 false 。
单词必须按照字母顺序，通过相邻的单元格内的字母构成，其中“相邻”单元格是那些水平相邻或垂直相邻的单元格。同一个单元格内的字母不允许被重复使用。
输入：board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "ABCCED"
输出：true

输入：board = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], word = "SEE"
输出：true
*/
public static boolean exist(char[][] board, String word) {
    char[] words = word.toCharArray();
    for (int i = 0; i < board.length; i++) {
        for (int j = 0; j < board[0].length; j++) {
            if (dfs(board, words, i, j, 0))
                return true;
        }
    }
    return false;
}

public static boolean dfs(char[][] board, char[] word, int i, int j, int k) {
    if (i >= board.length
            || i < 0
            || j >= board[0].length
            || j < 0
            || board[i][j] != word[k])
        return false;
    if (k == word.length - 1)
        return true;
    board[i][j] = '\0';
    boolean res = dfs(board, word, i + 1, j, k + 1)
            || dfs(board, word, i - 1, j, k + 1)
            || dfs(board, word, i, j + 1, k + 1)
            || dfs(board, word, i, j - 1, k + 1);
    board[i][j] = word[k];
    return res;
}


//分割回文串
/**
给你一个字符串 s，请你将 s 分割成一些子串，使每个子串都是 回文串,返回 s 所有可能的分割方案。
输入：s = "aab"
输出：[["a","a","b"],["aa","b"]]

输入：s = "a"
输出：[["a"]]
 * 
 */
public List<List<String>> partition(String s) {
        List<List<String>> lists = new ArrayList<>();
        Deque<String> deque = new LinkedList<>();
        backTracking(lists, deque, s, 0);
        return lists;
    }

private void backTracking(List<List<String>> lists, Deque<String> deque, String s, int startIndex) {
    // 如果起始位置大于s的大小，说明找到了一组分割方案
    if (startIndex >= s.length()) {
        lists.add(new ArrayList(deque));
        return;
    }
    for (int i = startIndex; i < s.length(); i++) {
        // 如果是回文子串，则记录
        if (isPalindrome(s, startIndex, i)) {
            String str = s.substring(startIndex, i + 1);
            deque.addLast(str);
        } else {
            continue;
        }
        // 起始位置后移，保证不重复
        backTracking(lists, deque, s, i + 1);
        deque.removeLast();
    }
}
//判断是否是回文串
private boolean isPalindrome(String s, int startIndex, int end) {
    for (int i = startIndex, j = end; i < j; i++, j--) {
        if (s.charAt(i) != s.charAt(j)) {
            return false;
        }
    }
    return true;
}
